<template>
    <div v-if="ops.editable" class="form-toolbar wc-x" :class="cls">
        <div class="d-bg">
            <div v-if="cls !== 'group-toolbar'" class="d-wrap">
                <i class="fa-solid fa-pen-to-square" v-tt:top-center-small="$__('Edit')" @click="editItem(index)"></i>
            </div>
            <div v-if="notFirst(index)" class="d-wrap">
                <i class="fa-solid" :class="prev" v-tt:top-center-small="$__('Move +')"
                    @click="moveItem(index, index - 1)"></i>
            </div>
            <div v-if="notLast(index)" class="d-wrap">
                <i class="fa-solid" :class="next" v-tt:top-center-small="$__('Move -')"
                    @click="moveItem(index, index + 1)"></i>
            </div>
            <div v-if="cls == 'section' && notPart()" class="d-wrap">
                <i class="fa-solid fa-floppy-disk" v-tt:top-center-small="$__('Save as Pattern')"
                    @click="saveAsPattern()"></i>
            </div>
            <div v-if="elements.length > 1" class="d-wrap">
                <i class="fa-solid fa-trash" v-tt:top-center-small="$__('Delete')" @click="del(index)"></i>
            </div>
            <div v-if="cls == 'element'" class="d-wrap">
                <i class="fa-solid fa-clone" v-tt:top-center-small="$__('Clone Element')" @click="clone()"></i>
            </div>
            <div v-if="cls !== 'section'" class="d-wrap">
                <i class="fa-solid fa-plus" v-tt:top-center-small="$__('Add')" @click="addItem(index)"></i>
            </div>
            <!-- <div v-if="cls == 'header'" class="d-wrap">
                <i class="fa-solid fa-plus" v-tt:top-center-small="$__('Add')" @click="addItem(index)"></i>
            </div> -->

            <div v-if="cls == 'section' && notPart()">
                <i class="add-section" :class="showClose()" v-tt:top-center-small="$__('Add')" @click="show = !show">
                    <transition name="slideV">
                        <div v-if="show" class="d-drop drop p-1 g-1">
                            <div class="but-blue fs-8" @click="addPattern()">
                                {{ $__('Add Pattern') }}
                            </div>
                            <div class="but-grey fs-8" @click="addItem(index)">
                                {{ $__('Add Empty Section') }}</div>
                        </div>
                    </transition>

                </i>
            </div>


        </div>

    </div>
</template>
<script>
import { ops } from '../data/data.js';
import { actions } from '../core/editor.js';

export default {
  name: 'JetToolbar',
  props: ['index','cls','type','elements','theme'],
  data() {
    return {
      ops,
      isAdmin: true,
      add: false,
      prev: 'fa-angle-up',
      next: 'fa-angle-down',
      show: false,
      save_as_pattern: false,
    };
  },
  methods: {
    // ---- SHIMS to avoid runtime errors with legacy template ----
    /** Legacy helper used in v-if conditions; true means we're editing the PAGE, not theme */
    notPart() {
      // Old code used ops.theme_part === 'page' — keep that behavior as "page scope"
      if (ops.ctx && ops.ctx.scope) {
        return ops.ctx.scope === 'page';
      }
      return ops.theme_part === 'page';
    },
    /** Safe length checks to avoid "undefined.length" */
    safeLen(arr) {
      return Array.isArray(arr) ? arr.length : 0;
    },

    // ---- Typical actions (wire them as you like) ----
    editItem(i) {
      ops.ctx.sectionIndex = i;
      ops.ctx.elementIndex = null;
      this.$emit('edit', i);
    },
    moveItem(from, to) {
      if (this.cls === 'section') {
        actions.moveSection(from, to);
      } else if (this.cls === 'element') {
        actions.moveElement(ops.ctx.sectionIndex, from, to);
      }
    },
    clone() {
      if (this.cls === 'section') {
        actions.cloneSection(this.index);
      } else if (this.cls === 'element') {
        actions.cloneElement(ops.ctx.sectionIndex, this.index);
      }
    },
    remove() {
      if (this.cls === 'section') {
        actions.deleteSection(this.index);
      } else if (this.cls === 'element') {
        actions.deleteElement(ops.ctx.sectionIndex, this.index);
      }
    },
    addElement() {
      actions.addElement(ops.ctx.sectionIndex, { type: 'paragraph', classes: { fs: '', col: '' }, el: { text: 'New' } });
    },
    notFirst(i) { return i > 0; },
    notLast(i) {
      const len = this.elements ? this.safeLen(this.elements) : 0;
      return i < len - 1;
    },
  },
  mounted() {
    if (this.type === 'row') {
      this.prev = 'fa-angle-left';
      this.next = 'fa-angle-right';
    }
  }
};
</script>

