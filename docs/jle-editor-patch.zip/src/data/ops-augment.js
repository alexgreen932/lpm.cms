// Side-effect module to augment and normalize `ops` at startup.
// Import this once (e.g., in main.js) so the rest of the app can safely rely on shapes.

import { ops } from './data.js';

/** Ensure a unified editor context exists */
ops.ctx = ops.ctx || {
  scope: 'page',          // 'page' | 'header' | 'footer'
  pageSlug: ops.current_page || 'homepage',
  sectionIndex: null,
  elementIndex: null,
};

/** Internal snapshot for dirty checks */
if (ops._lastSavedJson == null) ops._lastSavedJson = '';

/** Normalize page data */
ops.current_page_data = ops.current_page_data || { sections: [] };
ops.current_page_data.sections = Array.isArray(ops.current_page_data.sections) ? ops.current_page_data.sections : [];

/** Normalize theme based on your JSON shape (page, header{sec,sections}, footer{sec,sections}) */
ops.theme = ops.theme || {};
ops.theme.page = ops.theme.page || {};

ops.theme.header = ops.theme.header || {};
ops.theme.header.sec = ops.theme.header.sec || {};
ops.theme.header.sections = Array.isArray(ops.theme.header.sections) ? ops.theme.header.sections : [];

ops.theme.footer = ops.theme.footer || {};
ops.theme.footer.sec = ops.theme.footer.sec || {};
ops.theme.footer.sections = Array.isArray(ops.theme.footer.sections) ? ops.theme.footer.sections : [];

// Export nothing on purpose; this module mutates `ops` by side-effect.
