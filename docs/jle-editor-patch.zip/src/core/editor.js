// Tiny editor helpers around your existing `ops` object.
// Use relative imports (no @ alias) as requested.

import { ops } from '../data/data.js';

/** Get the array of sections for the current editing scope */
export function currentSections() {
  const scope = ops.ctx?.scope || 'page';
  if (scope === 'page') {
    return ops.current_page_data?.sections || [];
  }
  if (scope === 'header') {
    return ops.theme?.header?.sections || [];
  }
  if (scope === 'footer') {
    return ops.theme?.footer?.sections || [];
  }
  return [];
}

/** Get currently selected (section or element) */
export function getCurrentTarget() {
  const sections = currentSections();
  const si = ops.ctx?.sectionIndex;
  const ei = ops.ctx?.elementIndex;
  if (si == null) return null;
  const section = sections[si];
  if (!section) return null;
  if (ei == null) return section;
  return section.content?.[ei] || section.elements?.[ei] || null; // support both 'content' and 'elements'
}

/** Snapshot current area for dirty check */
export function snapshotSaved() {
  const scope = ops.ctx?.scope || 'page';
  let now = '';
  if (scope === 'page') {
    now = JSON.stringify(ops.current_page_data || {});
  } else if (scope === 'header') {
    now = JSON.stringify(ops.theme?.header || {});
  } else if (scope === 'footer') {
    now = JSON.stringify(ops.theme?.footer || {});
  }
  ops._lastSavedJson = now;
}

export function isDirty() {
  const prev = ops._lastSavedJson || '';
  snapshotSaved();
  return prev !== ops._lastSavedJson;
}

export const actions = {
  // Navigation
  openPage(slug) {
    ops.ctx.scope = 'page';
    ops.ctx.pageSlug = slug;
    ops.ctx.sectionIndex = null;
    ops.ctx.elementIndex = null;
    snapshotSaved();
  },
  openHeader() {
    ops.ctx.scope = 'header';
    ops.ctx.pageSlug = null;
    ops.ctx.sectionIndex = null;
    ops.ctx.elementIndex = null;
    snapshotSaved();
  },
  openFooter() {
    ops.ctx.scope = 'footer';
    ops.ctx.pageSlug = null;
    ops.ctx.sectionIndex = null;
    ops.ctx.elementIndex = null;
    snapshotSaved();
  },

  // Section operations
  addSection(sectionObj) {
    currentSections().push(sectionObj);
  },
  cloneSection(index) {
    const arr = currentSections();
    const s = arr[index];
    if (s) arr.splice(index + 1, 0, structuredClone(s));
  },
  moveSection(from, to) {
    const arr = currentSections();
    if (!Array.isArray(arr)) return;
    if (from === to || from < 0 || to < 0 || from >= arr.length) return;
    const [it] = arr.splice(from, 1);
    if (it) arr.splice(Math.min(to, arr.length), 0, it);
  },
  deleteSection(index) {
    const arr = currentSections();
    if (!Array.isArray(arr)) return;
    arr.splice(index, 1);
  },

  // Element operations (supports 'content' or 'elements' key)
  addElement(sectionIndex, el) {
    const s = currentSections()[sectionIndex];
    if (!s) return;
    if (Array.isArray(s.elements)) {
      s.elements.push(el);
    } else {
      s.content = Array.isArray(s.content) ? s.content : [];
      s.content.push(el);
    }
  },
  cloneElement(sectionIndex, elIndex) {
    const s = currentSections()[sectionIndex];
    if (!s) return;
    const arr = Array.isArray(s.elements) ? s.elements : (s.content = Array.isArray(s.content) ? s.content : []);
    const el = arr[elIndex];
    if (el) arr.splice(elIndex + 1, 0, structuredClone(el));
  },
  moveElement(sectionIndex, from, to) {
    const s = currentSections()[sectionIndex];
    if (!s) return;
    const arr = Array.isArray(s.elements) ? s.elements : (s.content = Array.isArray(s.content) ? s.content : []);
    if (from === to || from < 0 || to < 0 || from >= arr.length) return;
    const [it] = arr.splice(from, 1);
    if (it) arr.splice(Math.min(to, arr.length), 0, it);
  },
  deleteElement(sectionIndex, idx) {
    const s = currentSections()[sectionIndex];
    if (!s) return;
    const arr = Array.isArray(s.elements) ? s.elements : (s.content = Array.isArray(s.content) ? s.content : []);
    arr.splice(idx, 1);
  },

  markSaved() { snapshotSaved(); },
};
