# JLE minimal editor patch

This bundle adds a tiny editor core and safety normalizations without changing your existing structure.

## Files included
- `src/data/ops-augment.js` — normalizes `ops` at startup (adds `ctx`, ensures arrays exist).
- `src/core/editor.js` — small helper with `currentSections()`, `getCurrentTarget()`, `actions`, and dirty-checks.
- `src/page/jetToolbar.vue` — updated script block with shims (`notPart()`, `safeLen`) and wiring to editor actions.
- `src/main.js` — imports `./data/ops-augment.js` once.

## How to use
1. Ensure your theme and page JSONs are fetched as before. After they load, the shapes are already safe because `ops-augment` guards undefined arrays.
2. Use `ops.ctx.scope = 'page' | 'header' | 'footer'` when you switch tabs.
   - For header: call `actions.openHeader()`
   - For footer: call `actions.openFooter()`
   - For a page: `actions.openPage(slug)`
3. Toolbars and forms can now use `actions.*` to add/clone/move/delete sections/elements.
