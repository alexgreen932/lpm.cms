/**
 * Tiny UI controller for offcanvas panels.
 * Markup expectations:
 *   - Trigger buttons: <button data-toggle="offcanvas" data-target="#off-left"></button>
 *                      <button data-toggle="offcanvas" data-target="#off-right"></button>
 *   - Panels: <aside id="off-left" class="offcanvas"></aside>
 *             <aside id="off-right" class="offcanvas"></aside>
 *   - Overlay: <div class="offcanvas-overlay" id="offcanvas-overlay"></div>
 *
 * Add 'has-fixed-header' to <body> so content is padded under header.
 */
(function () {
  var overlay = document.getElementById('offcanvas-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'offcanvas-overlay';
    overlay.className = 'offcanvas-overlay';
    document.body.appendChild(overlay);
  }
  document.body.classList.add('has-fixed-header');

  function closeAll() {
    document.querySelectorAll('.offcanvas.is-open').forEach(function (el) {
      el.classList.remove('is-open');
    });
    overlay.classList.remove('is-active');
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest('[data-toggle="offcanvas"]');
    if (t) {
      var sel = t.getAttribute('data-target');
      var panel = document.querySelector(sel);
      if (panel) {
        var isOpen = panel.classList.contains('is-open');
        closeAll();
        if (!isOpen) {
          panel.classList.add('is-open');
          overlay.classList.add('is-active');
        }
      }
      e.preventDefault();
      return;
    }
    if (e.target === overlay || e.target.closest('[data-dismiss="offcanvas"]')) {
      closeAll();
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAll();
  });
})();
