<?php
if (!defined('ABSPATH'))
    die('No direct access allowed');

switch ($type) {
    case 'tabs':
    default :
        ?>
        </div> 
    <?php
}

