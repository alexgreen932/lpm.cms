<?php

if (!defined('ABSPATH'))
    die('No direct access allowed');

return [
    [
        'title' => esc_html__('Notice', 'woocommerce-products-filter'),
        'description' => esc_html__('This is application and all its settings you can find in HUSKY options page -> tab Structure', 'woocommerce-products-filter'),
        'element' => 'xxx',
        'field' => 'xxx',
        'value' => 0
    ]
];

