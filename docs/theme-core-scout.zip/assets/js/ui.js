
(function () {
  var overlay = document.getElementById('offcanvas-overlay');
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'offcanvas-overlay';
    overlay.className = 'offcanvas-overlay';
    document.body.appendChild(overlay);
  }
  document.body.classList.add('has-fixed-header');

  function closeAll() {
    var open = document.querySelectorAll('.offcanvas.is-open');
    for (var i=0;i<open.length;i++){ open[i].classList.remove('is-open'); }
    overlay.classList.remove('is-active');
  }

  document.addEventListener('click', function (e) {
    var t = e.target.closest ? e.target.closest('[data-toggle="offcanvas"]') : null;
    if (t) {
      var sel = t.getAttribute('data-target');
      var panel = document.querySelector(sel);
      if (panel) {
        var isOpen = panel.classList.contains('is-open');
        closeAll();
        if (!isOpen) { panel.classList.add('is-open'); overlay.classList.add('is-active'); }
      }
      if (e.preventDefault) e.preventDefault();
      return false;
    }
    if (e.target === overlay || (e.target.closest && e.target.closest('[data-dismiss="offcanvas"]'))) {
      closeAll();
    }
  });

  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeAll();
  });
})();
